﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GenText : MonoBehaviour {

	public Text ScriptText;

	private IEnumerator Start () {

		ScriptText.text = "0";

		while (true) {
			int num = int.Parse(ScriptText.text) + 1;
			ScriptText.text = num.ToString();

			yield return new WaitForSeconds (11);
		}
	}
	

}
